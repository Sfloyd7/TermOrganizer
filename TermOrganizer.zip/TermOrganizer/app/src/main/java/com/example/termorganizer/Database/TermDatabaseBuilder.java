package com.example.termorganizer.Database;


import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.room.TypeConverters;

import com.example.termorganizer.DAO.AssessmentDAO;
import com.example.termorganizer.DAO.CourseDAO;
import com.example.termorganizer.DAO.TermDAO;
import com.example.termorganizer.Entities.Assessment;
import com.example.termorganizer.Entities.Course;
import com.example.termorganizer.Entities.Term;

@Database(entities = {Term.class, Course.class, Assessment.class}, version=2, exportSchema = false)
@TypeConverters(DateConverter.class)
public abstract class TermDatabaseBuilder extends RoomDatabase {

    public abstract TermDAO TermDao();
    public abstract CourseDAO CourseDao();
    public abstract AssessmentDAO AssessmentDao();

    private static volatile TermDatabaseBuilder INSTANCE;

    static  TermDatabaseBuilder getDatabase(final Context context){
        if(INSTANCE==null){
            synchronized (TermDatabaseBuilder.class){
                if(INSTANCE==null){
                    INSTANCE= Room.databaseBuilder(context.getApplicationContext(),TermDatabaseBuilder.class,"MyTermDatabase.db")
                            .fallbackToDestructiveMigration()
                            .build();
                }
            }
        }
        return INSTANCE;
    }
}
