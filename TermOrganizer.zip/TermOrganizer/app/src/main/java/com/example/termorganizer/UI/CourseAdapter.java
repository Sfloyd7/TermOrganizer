package com.example.termorganizer.UI;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.termorganizer.Entities.Course;
import com.example.termorganizer.R;

import org.w3c.dom.Text;

import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Locale;

public class CourseAdapter extends RecyclerView.Adapter<CourseAdapter.CourseViewHolder> {
    class CourseViewHolder extends RecyclerView.ViewHolder {
        private final TextView CourseItemView;
        private final TextView CourseItemView2;
        private CourseViewHolder(View itemView){
            super (itemView);
            CourseItemView=itemView.findViewById(R.id.courseIdTextvw);
            CourseItemView2 = itemView.findViewById(R.id.courseNameTextvw);
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    int position = getAdapterPosition();
                    final Course current = mCourse.get(position);
                    Intent intent = new Intent(context, DetailedCourse.class);
                    String myFormat = "MM/dd/yy";
                    SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);
                    intent.putExtra("id",current.getCourseId());
                    intent.putExtra("name",current.getCourseName());
                    intent.putExtra("start",sdf.format(current.getStartDate()));
                    intent.putExtra("end",sdf.format(current.getEndDate()));
                    intent.putExtra("status",current.getStatus());
                    intent.putExtra("instName",current.getInstName());
                    intent.putExtra("instPhone",current.getInstPhone());
                    intent.putExtra("instEmail",current.getInstEmail());
                    intent.putExtra("note",current.getNote());
                    intent.putExtra("termId",current.getTermID());
                    context.startActivity(intent);

                }
            });
        }

    }
    private List<Course> mCourse;
    private final Context context;
    private final LayoutInflater mInflater;

    public CourseAdapter(Context context){
        mInflater= LayoutInflater.from(context);
        this.context = context;
    }

    @NonNull
    @Override
    public CourseAdapter.CourseViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView= mInflater.inflate(R.layout.course_list_item,parent,false);
        return new CourseViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull CourseAdapter.CourseViewHolder holder, int position) {
        if(mCourse != null){
            Course current = mCourse.get(position);
            holder.CourseItemView.setText(Integer.toString(current.getCourseId()));
            holder.CourseItemView2.setText(current.getCourseName());
        }
        else{
            holder.CourseItemView.setText("No Courses");
            holder.CourseItemView2.setText("No Courses");
        }

    }

    public void setCourse(List<Course> course){
        mCourse = course;
        notifyDataSetChanged();
    }

    @Override
    public int getItemCount() {
        return mCourse.size();
    }
}
