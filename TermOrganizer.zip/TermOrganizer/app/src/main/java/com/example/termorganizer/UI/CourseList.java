package com.example.termorganizer.UI;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;

import com.example.termorganizer.Database.Repository;
import com.example.termorganizer.Entities.Course;
import com.example.termorganizer.Entities.Term;
import com.example.termorganizer.R;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class CourseList extends AppCompatActivity {
    private Repository repository;
    String name;
    EditText editName;
    int termId;
    int courseId;
    List<Course> filteredCourse = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {


        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_course_list);
        Objects.requireNonNull(getSupportActionBar()).setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);

        termId = getIntent().getIntExtra("id", -1);
        name=getIntent().getStringExtra("name");


        editName = findViewById(R.id.courseName);
        repository = new Repository(getApplication());
        //List<Course> allCourse = repository.getAllCourse();
        for(Course c:repository.getAllCourse()){
            if (c.getTermID()==termId)filteredCourse.add(c);
        }
        RecyclerView recyclerView=findViewById(R.id.courseListRecycler);
        final CourseAdapter courseAdapter = new CourseAdapter(this);
        recyclerView.setAdapter(courseAdapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        courseAdapter.setCourse(filteredCourse);
        //courseAdapter.setCourse(allCourse);





    }
    public boolean onCreateOptionsMenu(Menu menu){
        getMenuInflater().inflate(R.menu.menu_recyclerview,menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                this.finish();
                return true;
            case R.id.refresh:
                repository  = new Repository((getApplication()));
                filteredCourse.clear();
                for(Course c:repository.getAllCourse()){
                    if (c.getTermID()==termId)filteredCourse.add(c);
                }
                final CourseAdapter courseAdapter = new CourseAdapter(this);
                RecyclerView recyclerView = findViewById(R.id.courseListRecycler);
                recyclerView.setAdapter(courseAdapter);
                recyclerView.setLayoutManager(new LinearLayoutManager(this));
                courseAdapter.setCourse(filteredCourse);
        }
        return super.onOptionsItemSelected(item);
    }

    public void addCourse(View view) {
        Intent intent = new Intent(CourseList.this, DetailedCourse.class);
        intent.putExtra("termId",termId);
        startActivity(intent);
    }

    //public void
}