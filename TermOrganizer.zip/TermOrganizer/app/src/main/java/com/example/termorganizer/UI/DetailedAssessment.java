package com.example.termorganizer.UI;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlarmManager;
import android.app.DatePickerDialog;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.sax.StartElementListener;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;

import com.example.termorganizer.Database.Repository;
import com.example.termorganizer.Entities.Assessment;
import com.example.termorganizer.R;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.Objects;

public class DetailedAssessment extends AppCompatActivity {


    int id;
    String assessmentName;
    String assessmentType;
    String Type;
    String startDate;
    String endDate;
    int courseId;
    EditText editName;
    EditText editStart;
    EditText editEnd;
    Repository repository;
    Assessment currentAssessment;

    final Calendar myCalendarEnd = Calendar.getInstance();
    final Calendar myCalendarStart = Calendar.getInstance();
    DatePickerDialog.OnDateSetListener assessmentEndDate;
    DatePickerDialog.OnDateSetListener assessmentStartDate;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detailed_assessment);
        Objects.requireNonNull(getSupportActionBar()).setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);

        id = getIntent().getIntExtra("id", -1);
        courseId = getIntent().getIntExtra("courseId", -1);
        assessmentName = getIntent().getStringExtra("name");
        editName = findViewById(R.id.AssessmentName);
        editName.setText(assessmentName);
        Type = getIntent().getStringExtra("type");
        /*if(radioGroup.getCheckedRadioButtonId() == R.id.ObjectiveRadio){
            assessmentType = "Objective"; }
        else{assessmentType = "Performance";}*/
        if (Type != null) {
            RadioGroup radioGroup = (RadioGroup) findViewById(R.id.typeGroup);
            if (Type.equals("Objective")) {
                radioGroup.check(R.id.ObjectiveRadio);
                //findViewById(R.id.ObjectiveRadio).setSelected(true);
            } else {
                radioGroup.check(R.id.PerformanceRadio);
                //findViewById(R.id.PerformanceRadio).setSelected(true);
            }
        } else {
            RadioGroup radioGroup = (RadioGroup) findViewById(R.id.typeGroup);
            radioGroup.check(R.id.PerformanceRadio);
            ;
        }
        startDate = getIntent().getStringExtra("start");
        editStart = findViewById(R.id.startDate);
        editStart.setText(startDate);
        endDate = getIntent().getStringExtra("end");
        editEnd = findViewById(R.id.endDate);
        editEnd.setText(endDate);
        repository = new Repository(getApplication());
        assessmentStartDate = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker datePicker, int year, int monthOfYear, int dayOfMonth) {
                myCalendarStart.set(Calendar.YEAR, year);
                myCalendarStart.set(Calendar.MONTH, monthOfYear);
                myCalendarStart.set(Calendar.DAY_OF_MONTH, dayOfMonth);

                String myFormat = "MM/dd.yy";
                SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);

                updateLabelStart();
            }
        };
        assessmentEndDate = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker datePicker, int year, int monthOfYear, int dayOfMonth) {

                myCalendarEnd.set(Calendar.YEAR, year);
                myCalendarEnd.set(Calendar.MONTH, monthOfYear);
                myCalendarEnd.set(Calendar.DAY_OF_MONTH, dayOfMonth);

                String myFormat = "MM/dd.yy";
                SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);

                updateLabelEnd();
            }
        };

        editStart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new DatePickerDialog(DetailedAssessment.this, assessmentStartDate, myCalendarStart
                        .get(Calendar.YEAR), myCalendarStart.get(Calendar.MONTH), myCalendarStart.get(Calendar.DAY_OF_MONTH)).show();
            }
        });

        editEnd.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View v){
                new DatePickerDialog(DetailedAssessment.this, assessmentEndDate,myCalendarEnd
                        .get(Calendar.YEAR), myCalendarEnd.get(Calendar.MONTH),
                        myCalendarEnd.get(Calendar.DAY_OF_MONTH)).show();
            }
        });
    }

    private void updateLabelStart(){
        String myFormat = "MM/dd/yy";
        SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);

        editStart.setText(sdf.format(myCalendarStart.getTime()));
    }
    private void updateLabelEnd(){

        String myFormat = "MM/dd/yy";
        SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);

        editEnd.setText(sdf.format(myCalendarEnd.getTime()));

    }
    public boolean onCreateOptionsMenu(Menu menu){
        getMenuInflater().inflate(R.menu.menu_assessment,menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                this.finish();
                return true;
            case R.id.notifyStart:
                String startDate = editStart.getText().toString();
                String myFormat = "MM/dd/yy";
                SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);
                Date myDate = null;
                try{
                    myDate = sdf.parse(startDate);
                } catch (ParseException e) {
                    e.printStackTrace();
                }
                Long trigger = myDate.getTime();
                Intent intent = new Intent(DetailedAssessment.this, MyReceiver.class);
                intent.putExtra("key", "Test " + editName.getText().toString() + " is about to start" );
                PendingIntent sender = PendingIntent.getBroadcast(DetailedAssessment.this, ++MainActivity.numAlert,intent, 0);
                AlarmManager alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
                alarmManager.set(AlarmManager.RTC_WAKEUP, trigger, sender);
                return true;

            case R.id.notifyEnd:
                String endDate = editEnd.getText().toString();
                Date DateEnd = null;
                String myFormat2 = "MM/dd/yy";
                SimpleDateFormat sdf2 = new SimpleDateFormat(myFormat2, Locale.US);
                try{
                    DateEnd = sdf2.parse(endDate);
                } catch (ParseException e) {
                    e.printStackTrace();
                }
                Long trigger2 = DateEnd.getTime();
                Intent intent2 = new Intent(DetailedAssessment.this, MyReceiver.class);
                intent2.putExtra("key", "Test " + editName.getText().toString() + " is about to end");
                PendingIntent sender2 = PendingIntent.getBroadcast(DetailedAssessment.this, ++MainActivity.numAlert,intent2, 0);
                AlarmManager alarmManager2 = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
                alarmManager2.set(AlarmManager.RTC_WAKEUP,trigger2,sender2);
                return true;

            case R.id.delete:
                for (Assessment a:repository.getAllAssessment()){
                    if(a.getAssessmentId() == getIntent().getIntExtra("id",-1))currentAssessment = a;
                }
                repository.delete(currentAssessment);
        }
        return super.onOptionsItemSelected(item);
    }

    public void onClickSave(View view) {
        String name = editName.getText().toString();
        String myFormat = "MM/dd/yy";
        SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);
        Date EndDateText = null;

        try{

            EndDateText = sdf.parse(String.valueOf(editEnd.getText()));
        }
        catch (Exception e){
            e.printStackTrace();
        }
        Date startDateText = null;

        try{

            startDateText = sdf.parse(String.valueOf(editEnd.getText()));
        }
        catch (Exception e){
            e.printStackTrace();
        }
RadioGroup radioGroup = (RadioGroup) findViewById(R.id.typeGroup);
        int test3 = radioGroup.getCheckedRadioButtonId();


        if(radioGroup.getCheckedRadioButtonId() == R.id.ObjectiveRadio){
            assessmentType = "Objective"; }
        else{assessmentType = "Performance";}
        if(id == -1){
            int newId;

            if (repository.getAllAssessment().size()==0){
                newId=1;
            }
            else{
            newId = repository.getAllAssessment().get(repository.getAllAssessment().size() - 1).getAssessmentId() +1;}
            Assessment assessment = new Assessment(newId, name, assessmentType, startDateText, EndDateText, courseId);
            repository.insert(assessment);

        }
        else{
            Assessment oldAssessment = new Assessment(id, name, assessmentType, startDateText, EndDateText, courseId);
            repository.update(oldAssessment);
        }
        Intent intent = new Intent(DetailedAssessment.this, TermList.class);
        startActivity(intent);
    }


}