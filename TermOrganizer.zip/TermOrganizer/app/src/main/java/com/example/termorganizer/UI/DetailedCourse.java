package com.example.termorganizer.UI;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.AlarmManager;
import android.app.DatePickerDialog;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.DatePicker;
import android.widget.EditText;

import com.example.termorganizer.Database.Repository;
import com.example.termorganizer.Entities.Assessment;
import com.example.termorganizer.Entities.Course;
import com.example.termorganizer.Entities.Term;
import com.example.termorganizer.R;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Objects;

public class DetailedCourse extends AppCompatActivity {

    Repository repository;
    int courseId;

    String courseName;
    String startDate;
    String endDate;
    String status;
    String instName;
    String instPhone;
    String instEmail;
    String note;
    int termId;
    EditText editName;
    EditText editStart;
    EditText editEnd;
    EditText editStatus;
    EditText editInstName;
    EditText editInstPhone;
    EditText editInstEmail;
    EditText editNote;
    Course currentCourse;
    final Calendar myCalendarStart = Calendar.getInstance();
    final Calendar myCalendarEnd = Calendar.getInstance();

    List<Assessment> filteredAssessment = new ArrayList<>();

    DatePickerDialog.OnDateSetListener courseStartDate;
    DatePickerDialog.OnDateSetListener courseEndDate;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detailed_course);
        Objects.requireNonNull(getSupportActionBar()).setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);


        courseId = getIntent().getIntExtra("id", -1);
        courseName = getIntent().getStringExtra("name");
        editName = findViewById(R.id.courseName);
        editName.setText(courseName);
        startDate = getIntent().getStringExtra("start");
        editStart = findViewById(R.id.startDate);
        editStart.setText(startDate);
        endDate = getIntent().getStringExtra("end");
        editEnd = findViewById(R.id.endDate);
        editEnd.setText(endDate);
        status = getIntent().getStringExtra("status");
        editStatus = findViewById(R.id.status);
        editStatus.setText(status);
        instName = getIntent().getStringExtra("instName");
        editInstName = findViewById(R.id.instructorName);
        editInstName.setText(instName);
        instPhone = getIntent().getStringExtra("instPhone");
        editInstPhone = findViewById(R.id.instructorNumber);
        editInstPhone.setText(instPhone);
        instEmail = getIntent().getStringExtra("instEmail");
        editInstEmail = findViewById(R.id.instructorEmail);
        editInstEmail.setText(instEmail);
        note = getIntent().getStringExtra("note");
        editNote = findViewById(R.id.note);
        editNote.setText(note);
        termId = getIntent().getIntExtra("termId",-1);

        RecyclerView recyclerView = findViewById(R.id.assessmentListRecycler);
        repository = new Repository(getApplication());
        List<Assessment> allAssessments = repository.getAllAssessment();
        for(Assessment a:repository.getAllAssessment()){
            if(a.getCourseId()==courseId)filteredAssessment.add(a);
        }
        RecyclerView recyclerView1 = findViewById(R.id.assessmentListRecycler);
        final AssessmentAdapter assessmentAdapter = new AssessmentAdapter(this);
        recyclerView1.setAdapter(assessmentAdapter);
        recyclerView1.setLayoutManager(new LinearLayoutManager(this));
        //assessmentAdapter.setAssessment(allAssessments);
        assessmentAdapter.setAssessment(filteredAssessment);

        courseStartDate = new DatePickerDialog.OnDateSetListener() {

            @Override
            public void onDateSet(DatePicker datePicker, int year, int monthOfYear, int dayOfMonth) {
                myCalendarStart.set(Calendar.YEAR,year);
                myCalendarStart.set(Calendar.MONTH,monthOfYear);
                myCalendarStart.set(Calendar.DAY_OF_MONTH,dayOfMonth);

                String myFormat = "MM/dd/yy";
                SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);

                updateLabelStart();
            }
        };
        courseEndDate = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker datePicker, int year, int monthOfYear, int dayOfMonth) {

                myCalendarEnd.set(Calendar.YEAR, year);
                myCalendarEnd.set(Calendar.MONTH, monthOfYear);
                myCalendarEnd.set(Calendar.DAY_OF_MONTH, dayOfMonth);

                String myFormat = "MM/dd/yy";
                SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);

                updateLabelEnd();

            }
        };

        editStart.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View view) {
                new DatePickerDialog(DetailedCourse.this, courseStartDate,myCalendarStart
                .get(Calendar.YEAR), myCalendarStart.get(Calendar.MONTH),
                        myCalendarStart.get(Calendar.DAY_OF_MONTH)).show();
            }
        });

        editEnd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new DatePickerDialog(DetailedCourse.this, courseEndDate, myCalendarEnd
                .get(Calendar.YEAR),myCalendarEnd.get(Calendar.MONTH),
                        myCalendarEnd.get(Calendar.DAY_OF_MONTH)).show();
            }
        });

    }

    private void updateLabelStart(){
        String myFormat = "MM/dd/yy";
        SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);

        editStart.setText(sdf.format(myCalendarStart.getTime()));
    }
    private void updateLabelEnd(){
        String myFormat = "MM/dd/yy";
        SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);

        editEnd.setText(sdf.format(myCalendarEnd.getTime()));
    }
    public boolean onCreateOptionsMenu(Menu menu){
        getMenuInflater().inflate(R.menu.menu_course,menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                this.finish();
                return true;
            case R.id.share:
                Intent sendIntent = new Intent();
                sendIntent.setAction(Intent.ACTION_SEND);
                sendIntent.putExtra(Intent.EXTRA_TEXT, editNote.getText());
                sendIntent.putExtra(Intent.EXTRA_TITLE, "Course Name "+ editName.getText());
                sendIntent.setType("text/plain");

                Intent shareIntent = Intent.createChooser(sendIntent, null);
                startActivity(shareIntent);
                return true;
            case R.id.notifyStart:
                String startDate = editStart.getText().toString();
                String myFormat = "MM/dd/yy";
                SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);
                Date myDate = null;
                try{
                    myDate = sdf.parse(startDate);
                } catch (ParseException e) {
                    e.printStackTrace();
                }
                Long trigger = myDate.getTime();
                Intent intent = new Intent(DetailedCourse.this, MyReceiver.class);
                intent.putExtra("key", "Class " + editName.getText().toString() + " is about to start" );
                PendingIntent sender = PendingIntent.getBroadcast(DetailedCourse.this, ++MainActivity.numAlert,intent, 0);
                AlarmManager alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
                alarmManager.set(AlarmManager.RTC_WAKEUP, trigger, sender);
                return true;
            case R.id.notifyEnd:
                String endDate = editEnd.getText().toString();
                String myFormat2 = "MM/dd/yy";
                SimpleDateFormat sdf2 = new SimpleDateFormat(myFormat2, Locale.US);
                Date DateEnd = null;
                try{
                    DateEnd = sdf2.parse(endDate);
                } catch (ParseException e) {
                    e.printStackTrace();
                }
                Long trigger2 = DateEnd.getTime();
                Intent intent2 = new Intent(DetailedCourse.this, MyReceiver.class);
                intent2.putExtra("key", "Class " + editName.getText().toString() + " is about to end");
                PendingIntent sender2 = PendingIntent.getBroadcast(DetailedCourse.this, ++MainActivity.numAlert,intent2, 0);
                AlarmManager alarmManager2 = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
                alarmManager2.set(AlarmManager.RTC_WAKEUP,trigger2,sender2);
                return true;
            case R.id.delete:
                for(Course c:repository.getAllCourse()){
                    if(c.getCourseId() == getIntent().getIntExtra("id", -1)) currentCourse = c;
                }
                repository.delete(currentCourse);
        }
        return super.onOptionsItemSelected(item);
    }


    public void enterAssessment(View view) {

        String name = editName.getText().toString();
        String myFormat = "MM/dd/yy";
        SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);
        Date startDateText = null;
        Date EndDateText = null;

        try{

            startDateText = sdf.parse(String.valueOf(editStart.getText()));
            EndDateText = sdf.parse(String.valueOf(editEnd.getText()));
        }
        catch (Exception e){
            e.printStackTrace();
        }
        String status = editStatus.getText().toString();
        String instName = editInstName.getText().toString();
        String instEmail = editInstEmail.getText().toString();
        String instPhone = editInstPhone.getText().toString();
        String note = editNote.getText().toString();


        if(courseId == -1) {
            int newId;
            if (repository.getAllCourse().size()==0){
                newId=1;
            }
            else{
                newId = repository.getAllCourse().get(repository.getAllCourse().size() - 1).getCourseId() +1;}
            Course course = new Course(newId, name, startDateText, EndDateText,status,instName,instPhone,instEmail,note,termId);
            repository.insert(course);

        }
        else {
            Course oldCourse = new Course(courseId, name, startDateText, EndDateText,status,instName,instPhone,instEmail,note,termId);
            repository.update(oldCourse);
        }

        Intent intent = new Intent(DetailedCourse.this, DetailedAssessment.class);
        intent.putExtra("courseId", courseId);
        startActivity(intent);
    }

    public void onClickSave(View view) {
        String name = editName.getText().toString();
        String myFormat = "MM/dd/yy";
        SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);
        Date startDateText = null;
        Date EndDateText = null;

        try{

            startDateText = sdf.parse(String.valueOf(editStart.getText()));
            EndDateText = sdf.parse(String.valueOf(editEnd.getText()));
        }
        catch (Exception e){
            e.printStackTrace();
        }
        String status = editStatus.getText().toString();
        String instName = editInstName.getText().toString();
        String instEmail = editInstEmail.getText().toString();
        String instPhone = editInstPhone.getText().toString();
        String note = editNote.getText().toString();


        if(courseId == -1) {
            int newId;
            if (repository.getAllCourse().size()==0){
                newId=1;
            }
            else{
            newId = repository.getAllCourse().get(repository.getAllCourse().size() - 1).getCourseId() +1;}
            Course course = new Course(newId, name, startDateText, EndDateText,status,instName,instPhone,instEmail,note,termId);
            repository.insert(course);

        }
        else {
            Course oldCourse = new Course(courseId, name, startDateText, EndDateText,status,instName,instPhone,instEmail,note,termId);
            repository.update(oldCourse);
        }

        Intent intent = new Intent(DetailedCourse.this, TermList.class);
        startActivity(intent);
    }
}