package com.example.termorganizer.UI;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.example.termorganizer.Database.Repository;
import com.example.termorganizer.Entities.Assessment;
import com.example.termorganizer.Entities.Course;
import com.example.termorganizer.Entities.Term;
import com.example.termorganizer.R;

import java.text.DateFormat;
import java.util.Date;

public class MainActivity extends AppCompatActivity {

    public static int numAlert;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Repository repository = new Repository(getApplication());
        Term term = new Term(1,"Term 1",  new Date(), new Date());
        repository.insert(term);

    }

    public void enterHere(View view) {
        Intent intent = new Intent(MainActivity.this, TermList.class);
        startActivity(intent);

    }
}