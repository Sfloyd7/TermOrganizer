package com.example.termorganizer.UI;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Toast;

import com.example.termorganizer.Database.Repository;
import com.example.termorganizer.Entities.Course;
import com.example.termorganizer.Entities.Term;
import com.example.termorganizer.R;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.Objects;

public class NewTerm extends AppCompatActivity {
    final Calendar myCalendarStart = Calendar.getInstance();
    final Calendar myCalendarEnd = Calendar.getInstance();

    DatePickerDialog.OnDateSetListener startDate;
    DatePickerDialog.OnDateSetListener endDate;

    EditText editName;
    EditText endText;
    EditText startText;
    Repository repository;
    int id;
    String name;
    String start;
    String  end;
    String startTxt;
    String endTxt;
    Term currentTerm;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_term);
        Objects.requireNonNull(getSupportActionBar()).setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        id = getIntent().getIntExtra("id", -1);
        name=getIntent().getStringExtra("name");
        start = getIntent().getStringExtra("start");
        end = getIntent().getStringExtra("end");

        editName = findViewById(R.id.termname);
        startText = findViewById(R.id.termStart);
        endText = findViewById(R.id.termEnd);
        //String myFormat = "MM/dd/yy";
        // sdf = new SimpleDateFormat(myFormat, Locale.US);
        //startTxt = sdf.format(start);
        //endTxt = sdf.format(end);
        repository = new Repository(getApplication());
        editName.setText(name);
        startText.setText(start);
        endText.setText(end);


        startDate= new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                myCalendarStart.set(Calendar.YEAR,year);
                myCalendarStart.set(Calendar.MONTH, monthOfYear);
                myCalendarStart.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                String myFormat = "MM/dd/yy";
                SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);

                updateLabelStart();
            }
        };
        endDate= new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                myCalendarEnd.set(Calendar.YEAR,year);
                myCalendarEnd.set(Calendar.MONTH, monthOfYear);
                myCalendarEnd.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                String myFormat = "MM/dd/yy";
                SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);

                updateLabelEnd();
            }
        };

        startText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new DatePickerDialog(NewTerm.this, startDate, myCalendarStart
                .get(Calendar.YEAR), myCalendarStart.get(Calendar.MONTH), myCalendarStart.get(Calendar.DAY_OF_MONTH)).show();
            }
        });
        endText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new DatePickerDialog(NewTerm.this, endDate, myCalendarEnd
                        .get(Calendar.YEAR), myCalendarStart.get(Calendar.MONTH), myCalendarStart.get(Calendar.DAY_OF_MONTH)).show();
            }
        });

    }

    private void updateLabelStart(){
        String myFormat = "MM/dd/yy";
        SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);

        startText.setText(sdf.format(myCalendarStart.getTime()));
    }
    private void updateLabelEnd(){
        String myFormat = "MM/dd/yy";
        SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);

        endText.setText(sdf.format(myCalendarEnd.getTime()));
    }


    public boolean onCreateOptionsMenu(Menu menu){
        getMenuInflater().inflate(R.menu.menu_term,menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                this.finish();
                return true;

            case R.id.delete:
                for(Term t:repository.getAllTerm()){
                    if(t.getTermId()==getIntent().getIntExtra("id",-1))currentTerm = t;
                }
                int numCourse = 0;
                for(Course course:repository.getAllCourse()){
                    if(course.getTermID()==currentTerm.getTermId())++numCourse;
                }
                if(numCourse == 0){
                    repository.delete(currentTerm);
                }
                else{
                    Toast.makeText(NewTerm.this,"Can't delete Term with Courses.", Toast.LENGTH_LONG).show();
                }
        }
        return super.onOptionsItemSelected(item);
    }

    public void saveTerm(View view) {
        String TermName = editName.getText().toString();
        String myFormat = "MM/dd/yy";
        SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);
        Date startDateText = null;
        Date EndDateText = null;

        try{
            startDateText = sdf.parse(String.valueOf(startText.getText()));

            EndDateText = sdf.parse(String.valueOf(endText.getText()));
        }
        catch (Exception e){
            e.printStackTrace();
        }

        if(id == -1) {
            int newId = repository.getAllTerm().get(repository.getAllTerm().size() - 1).getTermId() +1;
            Term term = new Term(newId, TermName, startDateText, EndDateText);
            repository.insert(term);
        }
        else {
            Term oldTerm = new Term(id,TermName,startDateText,EndDateText);
            repository.update(oldTerm);
        }

        Intent intent = new Intent(NewTerm.this, TermList.class);
        startActivity(intent);

    }


}